package Atividade11;

import java.util.Scanner;

public class Atividade11 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        double[] notas = new double[10];
        int quantidade = 0;
        int opcao = -1;

        while (opcao != 0) {
            System.out.println("Sistema de notas ");
            System.out.println("1 Cadastrar notas");
            System.out.println("2 Listar notas");
            System.out.println("3 Calcular media");
            System.out.println("4 Maior e menor nota");
            System.out.println("5 Consultar nota por numero do aluno");
            System.out.println("0 Sair");
            System.out.print("Escolha uma opcao: ");

            opcao = entrada.nextInt();

            switch (opcao) {
                case 1:
                    System.out.print("Quantos alunos? (1 a 10): ");
                    quantidade = entrada.nextInt();

                    if (quantidade < 1 || quantidade > 10) {
                        System.out.println("Quantidade invalida.");
                        quantidade = 0;
                    } else {
                        for (int i = 0; i < quantidade; i++) {
                            double nota;

                            System.out.print("Nota do aluno " + (i + 1) + " (0 a 10): ");
                            nota = entrada.nextDouble();

                            while (nota < 0 || nota > 10) {
                                System.out.println("Nota invalida.");
                                System.out.print("Digite uma nota entre 0 e 10: ");
                                nota = entrada.nextDouble();
                            }

                            notas[i] = nota;
                        }

                        System.out.println("Notas cadastradas.");
                    }
                    break;

                case 2:
                    if (quantidade == 0) {
                        System.out.println("Primeiro cadastre as notas usando a opcao 1.");
                    } else {
                        System.out.println("1Lista de notas:");

                        for (int i = 0; i < quantidade; i++) {
                            System.out.println("Aluno " + (i + 1) + ": " + notas[i]);
                        }
                    }
                    break;

                case 3:
                    if (quantidade == 0) {
                        System.out.println("Primeiro cadastre as notas usando a opcao 1.");
                    } else {
                        double soma = 0;

                        for (int i = 0; i < quantidade; i++) {
                            soma = soma + notas[i];
                        }

                        double media = soma / quantidade;
                        System.out.printf("Media da turma: %.2f%n", media);
                    }
                    break;

                case 4:
                    if (quantidade == 0) {
                        System.out.println("Primeiro cadastre as notas usando a opcao 1.");
                    } else {
                        double maior = notas[0];
                        double menor = notas[0];

                        for (int i = 1; i < quantidade; i++) {
                            if (notas[i] > maior) {
                                maior = notas[i];
                            }

                            if (notas[i] < menor) {
                                menor = notas[i];
                            }
                        }

                        System.out.println("Maior nota: " + maior);
                        System.out.println("Menor nota: " + menor);
                    }
                    break;

                case 5:
                    if (quantidade == 0) {
                        System.out.println("Primeiro cadastre as notas usando a opcao 1.");
                    } else {
                        System.out.print("Digite o numero do aluno que deseja consultar: ");
                        int aluno = entrada.nextInt();

                        if (aluno < 1 || aluno > quantidade) {
                            System.out.println("Numero de aluno invalido.");
                        } else {
                            System.out.println("Nota do aluno " + aluno + ": " + notas[aluno - 1]);
                        }
                    }
                    break;

                case 0:
                    System.out.println("Programa encerrado.");
                    break;

                default:
                    System.out.println("Opcao invalida.");
                    break;
            }
        }
    }
}
