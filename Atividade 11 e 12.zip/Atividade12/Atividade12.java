package Atividade12;

import java.util.Scanner;

public class Atividade12 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        String[] jogos = new String[5];
        int[] estoque = new int[5];
        int cadastrados = 0;
        int opcao = -1;

        while (opcao != 0) {
            System.out.println("Game Store ");
            System.out.println("1 Cadastrar jogo");
            System.out.println("2 Listar estoque");
            System.out.println("3 Vender jogo");
            System.out.println("4 Repor estoque");
            System.out.println("5 Consultar jogo");
            System.out.println("6 Ver total de unidades");
            System.out.println("0 Sair");
            System.out.print("Escolha uma opcao: ");

            opcao = entrada.nextInt();
            entrada.nextLine();

            switch (opcao) {
                case 1:
                    if (cadastrados == 5) {
                        System.out.println("Estoque cheio.");
                    } else {
                        System.out.print("Nome do jogo: ");
                        jogos[cadastrados] = entrada.nextLine();

                        System.out.print("Quantidade inicial: ");
                        int quantidadeInicial = entrada.nextInt();

                        while (quantidadeInicial < 0) {
                            System.out.println("A quantidade nao pode ser negativa.");
                            System.out.print("Digite zero ou uma quantidade maior: ");
                            quantidadeInicial = entrada.nextInt();
                        }

                        estoque[cadastrados] = quantidadeInicial;
                        cadastrados++;

                        System.out.println("Jogo cadastrado.");
                    }
                    break;

                case 2:
                    if (cadastrados == 0) {
                        System.out.println("Nenhum jogo cadastrado.");
                    } else {
                        System.out.println("Lista de jogos:");

                        for (int i = 0; i < cadastrados; i++) {
                            System.out.println((i + 1) + " - " + jogos[i] + ": "
                                    + estoque[i] + " unidades");
                        }
                    }
                    break;

                case 3:
                    if (cadastrados == 0) {
                        System.out.println("Nenhum jogo cadastrado.");
                    } else {
                        System.out.println("Lista de jogos:");

                        for (int i = 0; i < cadastrados; i++) {
                            System.out.println((i + 1) + " - " + jogos[i] + ": "
                                    + estoque[i] + " unidades");
                        }

                        System.out.print("Escolha o jogo: ");
                        int numeroJogo = entrada.nextInt();

                        if (numeroJogo < 1 || numeroJogo > cadastrados) {
                            System.out.println("Escolha invalida.");
                        } else {
                            System.out.print("Quantidade para vender: ");
                            int quantidadeVenda = entrada.nextInt();

                            if (quantidadeVenda <= 0) {
                                System.out.println("A quantidade precisa ser maior que zero.");
                            } else if (quantidadeVenda > estoque[numeroJogo - 1]) {
                                System.out.println("Estoque insuficiente.");
                            } else {
                                estoque[numeroJogo - 1] =
                                        estoque[numeroJogo - 1] - quantidadeVenda;

                                System.out.println("Venda realizada! " + jogos[numeroJogo - 1]
                                        + " agora tem " + estoque[numeroJogo - 1] + " unidades.");
                            }
                        }
                    }
                    break;

                case 4:
                    if (cadastrados == 0) {
                        System.out.println("Nenhum jogo cadastrado.");
                    } else {
                        System.out.println("Lista de jogos:");

                        for (int i = 0; i < cadastrados; i++) {
                            System.out.println((i + 1) + " - " + jogos[i] + ": "
                                    + estoque[i] + " unidades");
                        }

                        System.out.print("Escolha o jogo: ");
                        int numeroJogo = entrada.nextInt();

                        if (numeroJogo < 1 || numeroJogo > cadastrados) {
                            System.out.println("Escolha invalida.");
                        } else {
                            System.out.print("Quantidade para repor: ");
                            int quantidadeReposicao = entrada.nextInt();

                            if (quantidadeReposicao <= 0) {
                                System.out.println("A quantidade precisa ser maior que zero.");
                            } else {
                                estoque[numeroJogo - 1] =
                                        estoque[numeroJogo - 1] + quantidadeReposicao;

                                System.out.println("Estoque atualizado! " + jogos[numeroJogo - 1]
                                        + " agora tem " + estoque[numeroJogo - 1] + " unidades.");
                            }
                        }
                    }
                    break;

                case 5:
                    if (cadastrados == 0) {
                        System.out.println("Nenhum jogo cadastrado.");
                    } else {
                        System.out.print("Digite o numero do jogo: ");
                        int numeroJogo = entrada.nextInt();

                        if (numeroJogo < 1 || numeroJogo > cadastrados) {
                            System.out.println("Jogo nao encontrado.");
                        } else {
                            System.out.println("Jogo: " + jogos[numeroJogo - 1]);
                            System.out.println("Unidades: " + estoque[numeroJogo - 1]);
                        }
                    }
                    break;

                case 6:
                    int totalUnidades = 0;

                    for (int i = 0; i < cadastrados; i++) {
                        totalUnidades = totalUnidades + estoque[i];
                    }

                    System.out.println("Total de unidades na loja: " + totalUnidades);
                    break;

                case 0:
                    System.out.println("Obrigado por usar o sistema. Ate mais!");
                    break;

                default:
                    System.out.println("Opcao invalida.");
                    break;
            }
        }
    }
}